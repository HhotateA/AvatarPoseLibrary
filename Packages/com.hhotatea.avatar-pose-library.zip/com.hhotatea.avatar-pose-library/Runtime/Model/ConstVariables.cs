namespace com.hhotatea.avatar_pose_library.model
{
    public static class ConstVariables
    {
        public const string BaseName = "AvatarPoseLibrary";
        public const string OnPlayParamPrefix = "AnimPosePlay";
        public const string DummyParamPrefix = "AnimPoseDummy";
        
        /// <summary>
        /// パラメーター名
        /// </summary>
        public const string HeightParamPrefix = "AnimPoseHeight";
        public const string HeightUpdateParamPrefix = "AnimHeightUpdate";
        public const string BaseParamPrefix = "AnimPoseBase";
        public const string HeadParamPrefix = "AnimPoseHead";
        public const string ArmParamPrefix = "AnimPoseArm";
        public const string FootParamPrefix = "AnimPoseFoot";
        public const string FingerParamPrefix = "AnimPoseFinger";
        public const string FaceParamPrefix = "AnimPoseFace";
        public const string ActionParamPrefix = "AnimPoseAction";
        public const string SpeedParamPrefix = "AnimPoseSpeed";
        public const string ResetParamPrefix = "AnimPoseReset";
        public const string MirrorParamPrefix = "AnimPoseMirror";
        public const string MirrorCycleOffsetParamPrefix = "AnimPoseMirrorCycleOffset";
        public const string FlagParamPrefix = "AnimPoseFlag";
        public const string AudioParamPrefix = "AnimPoseAudio";
        public const string PoseSpaceParamPrefix = "AnimPoseSpace";

        /// <summary>
        /// State名
        /// </summary>
        public const string StateNameReset = "Reset";

        /// <summary>
        /// アニメーター名
        /// </summary>
        public const string MotionAnimatorPrefix = "AnimPoseMotion";
        public const string FxAnimatorPrefix = "AnimPoseFx";
        public const string ParamAnimatorPrefix = "AnimPoseParam";

        // 1つのIntパラメーターで管理するAnimationの最大数。
        public const int MaxAnimationState = 255;
        public const int PoseFlagCount = 2;
        public const int HashLong = 16;

        // 設定で使用するアイコン
        public const string warmIcon = "console.warnicon.sml";
    }
}
